/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.minecraftclone.core;

import static com.minecraftclone.core.Block.*;
import com.minecraftclone.core.CubeGenerator.Direction;
import java.util.ArrayList;
import java.util.List;
import org.joml.Matrix4f;
import static org.lwjgl.opengl.GL13.GL_TEXTURE0;
import static org.lwjgl.opengl.GL13.glActiveTexture;

public class Chunk {

    // … campos existentes …
    private Mesh grassMesh;
    private Mesh dirtMesh;
    private Mesh stoneMesh;

    public static final int SIZEx = 16;
    public static final int SIZEy = 16;
    public static final int SIZEz = 16;

    public static final int terrainHeight = 4;

    private boolean dirty = false;

    public final int chunkX, chunkY, chunkZ;
    private final Block[][][] blocks = new Block[SIZEx][SIZEy][SIZEz];

    public Chunk(int chunkX, int chunkY, int chunkZ) {
        this.chunkX = chunkX;
        this.chunkY = chunkY;
        this.chunkZ = chunkZ;
    }

    /**
     * Generación simple de bloques, por ahora piso sólido hasta y = 4
     */
    public void generate() {
        for (int x = 0; x < SIZEx; x++) {
            for (int y = 0; y < SIZEy; y++) {
                for (int z = 0; z < SIZEz; z++) {
                    if (y == terrainHeight) {
                        blocks[x][y][z] = Block.GRASS;
                    } else if (y < terrainHeight && y > 0) {
                        blocks[x][y][z] = DIRT;
                    } else if (y == 0) {
                        blocks[x][y][z] = STONE;
                    } else {
                        blocks[x][y][z] = AIR;
                    }
                }
            }
        }

        System.out.println("Generando chunk " + getKey());

        // Verificación segura: mostrar un bloque válido dentro del rango
        int testX = Math.min(4, SIZEx - 1);
        int testY = Math.min(4, SIZEy - 1);
        int testZ = Math.min(4, SIZEz - 1);

        Block testBlock = blocks[testX][testY][testZ];
        if (testBlock != null) {
            System.out.println("Bloque (" + testX + "," + testY + "," + testZ + ") = " + testBlock.getType());
        } else {
            System.out.println("Bloque (" + testX + "," + testY + "," + testZ + ") = null ⚠️");
        }
    }

    //Si el cubo esta de cara al cielo
    public boolean isExposedToSky(int x, int y, int z) {
        for (int ty = y + 1; ty < SIZEy; ty++) {
            if (blocks[x][ty][z] != null && blocks[x][ty][z].isSolid()) {
                return false; // hay un bloque encima
            }
        }
        return true;
    }

    /**
     * Establece un bloque dentro del chunk local
     */
    public void setBlock(int x, int y, int z, Block blockId) {
        if (blockId == null) {
            System.err.println("ERROR! se intentra colocar un bloque null en (" + x + "," + y + "," + z + ")");
            return;
        }

        if (x >= 0 && x < SIZEx && y >= 0 && y < SIZEy && z >= 0 && z < SIZEz) {
            blocks[x][y][z] = blockId;
            dirty = true;
            System.out.println("Bloque sobrescrito en" + x + "," + y + "," + z + "con " + blockId.getType());
        }

    }

    public boolean isDirty() {
        return dirty;
    }

    public void setDirty(boolean flag) {
        this.dirty = flag;
    }

    /**
     * Obtiene el bloque en coordenadas locales del chunk
     */
    public Block getBlock(int x, int y, int z) {
        if (x < 0 || x >= SIZEx || y < 0 || y >= SIZEy || z < 0 || z >= SIZEz) {
            return AIR;
        }
        if (blocks[x][y][z] == null) {
            return AIR;
        }
        if (x >= 0 && x < SIZEx && y >= 0 && y < SIZEy && z >= 0 && z < SIZEz) {
            return blocks[x][y][z];
        }
        return AIR;
    }

    /**
     * Construye o reconstruye la malla del chunk aplicando ocultación de caras
     */
    public void buildMesh() {
        // 1) Tres listas de floats para GRASS, DIRT y STONE:
        List<Float> grassVerts = new ArrayList<>();
        List<Float> dirtVerts = new ArrayList<>();
        List<Float> stoneVerts = new ArrayList<>();

        for (int x = 0; x < SIZEx; x++) {
            for (int y = 0; y < SIZEy; y++) {
                for (int z = 0; z < SIZEz; z++) {
                    Block block = blocks[x][y][z];
                    if (block != null && block.isSolid()) {
                        float[] cube = CubeGenerator.createCube(x, y, z, blocks);

                        // ¿De qué tipo es este bloque?
                        switch (block.getType()) {
                            case GRASS:
                                for (float f : cube) {
                                    grassVerts.add(f);
                                }
                                break;
                            case DIRT:
                                for (float f : cube) {
                                    dirtVerts.add(f);
                                }
                                break;
                            case STONE:
                                for (float f : cube) {
                                    stoneVerts.add(f);
                                }
                                break;
                            default:
                            // (si añades más tipos, agrégalos aquí)
                            }
                    }
                }
            }
        }

        // 2) Convertir las tres listas a tres arrays float[]
        if (!grassVerts.isEmpty()) {
            float[] gArr = new float[grassVerts.size()];
            for (int i = 0; i < gArr.length; i++) {
                gArr[i] = grassVerts.get(i);
            }
            if (grassMesh != null) {
                grassMesh.cleanup();
            }
            grassMesh = new Mesh(gArr);
        } else {
            grassMesh = null;
        }

        if (!dirtVerts.isEmpty()) {
            float[] dArr = new float[dirtVerts.size()];
            for (int i = 0; i < dArr.length; i++) {
                dArr[i] = dirtVerts.get(i);
            }
            if (dirtMesh != null) {
                dirtMesh.cleanup();
            }
            dirtMesh = new Mesh(dArr);
        } else {
            dirtMesh = null;
        }

        if (!stoneVerts.isEmpty()) {
            float[] sArr = new float[stoneVerts.size()];
            for (int i = 0; i < sArr.length; i++) {
                sArr[i] = stoneVerts.get(i);
            }
            if (stoneMesh != null) {
                stoneMesh.cleanup();
            }
            stoneMesh = new Mesh(sArr);
        } else {
            stoneMesh = null;
        }

        // 3) Limpiar la “antigua” malla completa (si la tenías)
        // (opcional, en tu caso ya no usas 'this.mesh' sino las tres nuevas)
    }

    /**
     * Verifica si un bloque vecino es aire o está fuera del chunk
     */
    public boolean isTransparent(int x, int y, int z) {
        if (x < 0 || x >= SIZEx || y < 0 || y >= SIZEy || z < 0 || z >= SIZEz) {
            return true; // Borde del chunk
        }
        return blocks[x][y][z] == Block.AIR;
    }

    public String getKey() {
        return chunkX + ",0," + chunkZ;
    }

    public void render(Matrix4f projection, Matrix4f view, ShaderProgram shader,
            Texture grassTex,
            Texture dirtTex,
            Texture stoneTex) {
        // PROYECCIÓN y VISTA ya las pasaste desde WorldManager

        Matrix4f model = new Matrix4f().translate(
                chunkX * SIZEx,
                chunkY * SIZEy,
                chunkZ * SIZEz
        );

        Matrix4f mvp = new Matrix4f(projection).mul(view).mul(model);

        // 1) Dibuja GRASS
        if (grassMesh != null) {
            shader.bind();
            shader.setUniformMat4("model", model);
            shader.setUniformMat4("mvp", mvp);
            glActiveTexture(GL_TEXTURE0);
            grassTex.bind();
            shader.setUniform1i("textureSampler", 0);
            grassMesh.render();
            shader.unbind();
        }

        // 2) Dibuja DIRT
        if (dirtMesh != null) {
            shader.bind();
            shader.setUniformMat4("model", model);
            shader.setUniformMat4("mvp", mvp);
            glActiveTexture(GL_TEXTURE0);
            dirtTex.bind();
            shader.setUniform1i("textureSampler", 0);
            dirtMesh.render();
            shader.unbind();
        }
        // 3) Dibuja STONE
        if (stoneMesh != null) {
            shader.bind();
            shader.setUniformMat4("model", model);
            shader.setUniformMat4("mvp", mvp);
            glActiveTexture(GL_TEXTURE0);
            stoneTex.bind();
            shader.setUniform1i("textureSampler", 0);
            stoneMesh.render();
            shader.unbind();
        }
    }

    public Mesh getMeshGrass() {
        return grassMesh;
    }

    public Mesh getMeshDirt() {
        return dirtMesh;
    }

    public Mesh getMeshStone() {
        return stoneMesh;
    }

    public Mesh getMeshByBlockType(BlockType type) {
        if (type == BlockType.DIRT) {
            return dirtMesh;
        }
        if (type == BlockType.GRASS) {
            return grassMesh;
        }
        if (type == BlockType.STONE) {
            return stoneMesh;
        }
        return null;
    }

    public void cleanup() {
        if (grassMesh != null) {
            grassMesh.cleanup();
        }
        if (dirtMesh != null) {
            dirtMesh.cleanup();
        }
        if (stoneMesh != null) {
            stoneMesh.cleanup();
        }
    }
}
