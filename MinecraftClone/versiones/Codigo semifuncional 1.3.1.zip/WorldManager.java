package com.minecraftclone.core;

import static com.minecraftclone.core.Block.*;
import static com.minecraftclone.core.Chunk.terrainHeight;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.joml.Vector3f;

public class WorldManager {

    // Mapa para almacenar chunks con clave: "chunkX,chunkY,chunkZ"
    final Map<String, Chunk> chunks = new HashMap<>();
    private static final int LOAD_RADIUS = 3;
    private final Camera camera;
    private final ShaderProgram shader;

    //TEXTURAAAAS
    private Texture grass;
    private Texture dirt;
    private Texture stone;

    //Colas de hilos
    protected static final ConcurrentLinkedQueue<Chunk> chunksToAdd = new ConcurrentLinkedQueue<>();
    protected static final ConcurrentLinkedQueue<Chunk> chunksToMesh = new ConcurrentLinkedQueue<>();
    protected static final ConcurrentLinkedQueue<Chunk> chunksToIntegrate = new ConcurrentLinkedQueue<>();

    public static final File worldFolder = new File("world");
    private ChunkLoaderThread chunkLoader;
    private ChunkSaveThread saveThread;
    private MeshBuilderThread meshBuilder;

    public static WorldManager instance;

    public WorldManager(Camera camera, ShaderProgram shader, Texture grass, Texture dirt, Texture stone) {
        this.camera = camera;
        instance = this;
        this.shader = shader;
        this.grass = grass;
        this.dirt = dirt;
        this.stone = stone;

        if (!worldFolder.exists()) {
            worldFolder.mkdirs();
        }
        saveThread = new ChunkSaveThread(this);

    }

    public void setMeshBuilder(MeshBuilderThread meshBuilder) {
        this.meshBuilder = meshBuilder;
    }

    /**
     * Obtiene un chunk por coordenadas de chunk, si no existe lo crea y genera.
     */
    public Chunk getChunk(int chunkX, int chunkY, int chunkZ) {
        String key = key(chunkX, chunkY, chunkZ);
        Chunk chunk = chunks.get(key);
        if (chunk == null) {
            chunk = new Chunk(chunkX, chunkY, chunkZ);
            chunk.generate(); // Genera el bloque con generación simple o procedural
            chunk.buildMesh();
            chunks.put(key, chunk);
        }
        return chunk;
    }

    public Map<String, Chunk> getChunks() {
        return chunks;
    }

    public void addChunk(Chunk chunk) {
        chunks.put(chunk.getKey(), chunk);
    }

    /**
     * Devuelve el bloque en coordenadas globales (x,y,z en bloques). Retorna 0
     * (aire) si fuera de chunks cargados.
     */
    public Block getBlockIfLoader(int x, int y, int z) {
        int chunkX = Math.floorDiv(x, Chunk.SIZEx);
        int chunkY = Math.floorDiv(y, Chunk.SIZEy);
        int chunkZ = Math.floorDiv(z, Chunk.SIZEz);

        String key = chunkX + "," + chunkY + "," + chunkZ;
        Chunk chunk = chunks.get(key);

        if (chunk == null) {
            System.out.println("El Chunk(" + key + ") no encontrado");
            return null;
        }

        int localX = Math.floorMod(x, Chunk.SIZEx);
        int localY = Math.floorMod(y, Chunk.SIZEy);
        int localZ = Math.floorMod(z, Chunk.SIZEz);

        Block b = chunk.getBlock(localX, localY, localZ);
        if (b == null) {
            System.out.println("El bloque(" + x + "," + y + "," + z + ") es null");
        }
        return b;
    }

    public Chunk getChunkWithoutMesh(String key) {
        return chunks.get(key);
    }

    /**
     * Establece un bloque en coordenadas globales. Reconstruye la malla del
     * chunk modificado.
     */
    public void setBlock(int x, int y, int z, Block blockId) {
        int chunkX = Math.floorDiv(x, Chunk.SIZEx);
        int chunkY = Math.floorDiv(y, Chunk.SIZEy);
        int chunkZ = Math.floorDiv(z, Chunk.SIZEz);

        Chunk chunk = getChunk(chunkX, chunkY, chunkZ);
        if (chunk == null) {
            return;
        }

        int localX = Math.floorMod(x, Chunk.SIZEx);
        int localY = Math.floorMod(y, Chunk.SIZEy);
        int localZ = Math.floorMod(z, Chunk.SIZEz);

        chunk.setBlock(localX, localY, localZ, blockId);

        // Reemplazo dinámico de GRASS por DIRT si se coloca un bloque encima
        if (blockId != Block.AIR) {
            int belowY = y - 1;
            if (belowY >= 0) {
                Block blockBelow = getBlockIfLoader(x, belowY, z);
                if (blockBelow == GRASS) {
                    setBlock(x, belowY, z, DIRT);
                }
            }
        }

        chunk.setDirty(true);
        chunk.buildMesh();

        saveThread.requestSave(chunk);
    }

    public void setBlockIfChunkExists(int x, int y, int z, Block blockId) {
        int chunkX = Math.floorDiv(x, Chunk.SIZEx);
        int chunkY = Math.floorDiv(y, Chunk.SIZEy);
        int chunkZ = Math.floorDiv(z, Chunk.SIZEz);

        String key = key(chunkX, chunkY, chunkZ);
        if (!chunks.containsKey(key)) {
            return; // No generes un chunk nuevo
        }
        Chunk chunk = chunks.get(key);
        int localX = Math.floorMod(x, Chunk.SIZEx);
        int localY = Math.floorMod(y, Chunk.SIZEy);
        int localZ = Math.floorMod(z, Chunk.SIZEz);

        chunk.setBlock(localX, localY, localZ, blockId);

        // Reemplazo dinámico de GRASS por DIRT si se coloca un bloque encima
        if (blockId != Block.AIR) {
            int belowY = y - 1;
            if (belowY >= 0) {
                Block blockBelow = getBlockIfLoader(x, belowY, z);
                if (blockBelow == GRASS) {
                    setBlock(x, belowY, z, DIRT);
                }
            }
        }

        chunk.setDirty(true);
        chunk.buildMesh();

        saveThread.requestSave(chunk);
    }

    //si tiene soporte
    public boolean hasSupport(int x, int y, int z) {
        return getBlockIfLoader(x, y - 1, z) != AIR
                || getBlockIfLoader(x + 1, y, z) != AIR
                || getBlockIfLoader(x - 1, y, z) != AIR
                || getBlockIfLoader(x, y, z + 1) != AIR
                || getBlockIfLoader(x, y, z - 1) != AIR;
    }

    //Limitar chunks
    public void updateChunks(Vector3f playerPos) {
        int playerChunkX = Math.floorDiv((int) playerPos.x, Chunk.SIZEx);
        int playerChunkZ = Math.floorDiv((int) playerPos.z, Chunk.SIZEz);

        Set<String> stillNeeded = new HashSet<>();
        List<int[]> toLoad = new ArrayList<>();

        for (int dx = -LOAD_RADIUS; dx <= LOAD_RADIUS; dx++) {
            for (int dz = -LOAD_RADIUS; dz <= LOAD_RADIUS; dz++) {
                int cx = playerChunkX + dx;
                int cz = playerChunkZ + dz;

                stillNeeded.add(key(cx, 0, cz));
                toLoad.add(new int[]{cx, cz});
            }
        }

        // Ordenar por distancia al jugador
        toLoad.sort(Comparator.comparingDouble(coord -> {
            float dx = playerChunkX - coord[0];
            float dz = playerChunkZ - coord[1];
            return dx * dx + dz * dz;
        }));

        // Encolar en orden de cercanía
        for (int[] coord : toLoad) {
            String k = key(coord[0], 0, coord[1]);
            if (!chunks.containsKey(k)) {
                chunkLoader.requestLoad(coord[0], coord[1]);
            }
        }

        // Descargar chunks fuera del radio
        chunks.keySet().removeIf(k -> {
            if (!stillNeeded.contains(k)) {
                saveChunk(chunks.get(k));
                chunks.get(k).cleanup();
                return true;
            }
            return false;
        });
    }

    public void saveChunk(Chunk chunk) {
        saveThread.requestSave(chunk);
    }

    public void saveChunkImmediate(Chunk chunk) throws IOException {
        String key = chunk.getKey();                  // por ejemplo: "0,0,0"
        File fileTmp = new File(worldFolder, key + ".tmp");
        File fileDat = new File(worldFolder, key + ".dat");

        // 1) Crear el .tmp y escribir sólo las capas no vacías:
        try (DataOutputStream out = new DataOutputStream(new FileOutputStream(fileTmp))) {
            // 1.1) Detectar qué capas Y tienen al menos un bloque ≠ AIR
            List<Integer> nonEmptyLayers = new ArrayList<>();
            for (int y = 0; y < Chunk.SIZEy; y++) {
                boolean hasBlock = false;
                for (int x = 0; x < Chunk.SIZEx && !hasBlock; x++) {
                    for (int z = 0; z < Chunk.SIZEz && !hasBlock; z++) {
                        if (chunk.getBlock(x, y, z) != Block.AIR) {
                            hasBlock = true;
                        }
                    }
                }
                if (hasBlock) {
                    nonEmptyLayers.add(y);
                }
            }

            // 1.2) Escribir cuántas capas no vacías vamos a guardar
            out.writeInt(nonEmptyLayers.size());

            // 1.3) Por cada capa Y, escribir primero el índice Y, y luego todos los bloques de esa capa
            for (int y : nonEmptyLayers) {
                out.writeInt(y); // índice de la capa
                for (int x = 0; x < Chunk.SIZEx; x++) {
                    for (int z = 0; z < Chunk.SIZEz; z++) {
                        Block b = chunk.getBlock(x, y, z);
                        out.writeInt(Block.getBlockId(b));
                    }
                }
            }

            // El try-with-resources se encarga de cerrar 'out' aquí al salir del bloque
        }

        // 2) Una vez fuera del try, el flujo ya está cerrado. Ahora podemos renombrar.
        //    Primero borramos el .dat viejo (si existe)
        if (fileDat.exists()) {
            if (!fileDat.delete()) {
                System.err.println("No se pudo borrar el archivo antiguo: " + fileDat.getPath());
                // Si quieres, puedes abortar aquí o programar un retry.
            }
        }

        // 3) Finalmente renombrar .tmp → .dat
        if (!fileTmp.renameTo(fileDat)) {
            System.err.println("No se pudo renombrar " + fileTmp.getName() + " a " + fileDat.getName());
            // Opcional: podrías volver a intentar más tarde, o moverlo a otra carpeta “retry/”
        }
    }

    public boolean loadChunk(Chunk chunk) {

        String filename = chunk.getKey() + ".dat";
        File file = new File(worldFolder, filename);
        File tmp = new File(worldFolder, chunk.getKey() + ".tmp");
        if (!file.exists() || tmp.exists()) {
            return false;
        }
        try (DataInputStream in = new DataInputStream(new FileInputStream(file))) {

            //Reinicio para evitar errores de caida
            // Comprobación del chunk del jugador
            int playerChunkX = Math.floorDiv((int) camera.getPosition().x, Chunk.SIZEx);
            int playerChunkZ = Math.floorDiv((int) camera.getPosition().z, Chunk.SIZEz);

            if (chunk.chunkX == playerChunkX && chunk.chunkZ == playerChunkZ) {
                Game.gravityDelayTime = Game.GRAVITY_COUNTDOWN_TIME;
            }

            //Game.gravityDelayTime = Game.GRAVITY_COUNTDOWN_TIME;
            // Inicializar todo con AIR primero para evitar nulos
            for (int x = 0; x < Chunk.SIZEx; x++) {
                for (int y = terrainHeight; y < Chunk.SIZEy; y++) {
                    for (int z = 0; z < Chunk.SIZEz; z++) {
                        chunk.setBlock(x, y, z, Block.AIR);
                    }
                }
            }

            int layerCount = in.readInt(); // cuántas capas hay

            for (int i = 0; i < layerCount; i++) {
                int y = in.readInt(); // índice de la capa

                for (int x = 0; x < Chunk.SIZEx; x++) {
                    for (int z = 0; z < Chunk.SIZEz; z++) {
                        int id = in.readInt();
                        Block b = Block.getBlockById(id);
                        chunk.setBlock(x, y, z, b);
                    }
                }
            }
            return true;

        } catch (IOException e) {
            System.err.println(" Error leyendo chunk " + chunk.getKey() + ": " + e.getMessage());
            return false;
        }
    }

    private Block getBlockById(int id) {
        if (id >= 0 && id < Block.BLOCKS.length) {
            return Block.BLOCKS[id];
        } else if (id == 0) {
            return Block.AIR;
        }

        return null;
    }

    public Chunk pollChunkToMesh() {
        return chunksToMesh.poll();
    }

    public void loadOrGenerateChunk(int chunkX, int chunkZ) {
        String key = key(chunkX, 0, chunkZ);

        // Si ya está cargado en memoria, no hacemos nada.
        if (chunks.containsKey(key)) {
            return;
        }

        // Si ya se pidió su carga (o está en proceso), tampoco hacemos nada.
        if (chunkLoader.hasPendingRequest(chunkX, chunkZ)) {
            return;
        }

        //Reinicio para evitar errores de caida
        // Comprobación del chunk del jugador
        int playerChunkX = Math.floorDiv((int) camera.getPosition().x, Chunk.SIZEx);
        int playerChunkZ = Math.floorDiv((int) camera.getPosition().z, Chunk.SIZEz);

        if (chunkX == playerChunkX && chunkZ == playerChunkZ) {
            Game.gravityDelayTime = Game.GRAVITY_COUNTDOWN_TIME;
        }

        // Si no, pedimos al hilo de carga que lo maneje
        chunkLoader.requestLoad(chunkX, chunkZ);

    }

    public void integrateLoadedChunks() {
        synchronized (chunksToAdd) {
            for (Chunk chunk : chunksToAdd) {
                //if (chunk == null) {
                //    continue;
                //}

                //Reinicio para evitar errores de caida
                // Comprobación del chunk del jugador
                int playerChunkX = Math.floorDiv((int) camera.getPosition().x, Chunk.SIZEx);
                int playerChunkZ = Math.floorDiv((int) camera.getPosition().z, Chunk.SIZEz);

                if (chunk.chunkX == playerChunkX && chunk.chunkZ == playerChunkZ) {
                    Game.gravityDelayTime = Game.GRAVITY_COUNTDOWN_TIME;
                }

                chunk.buildMesh(); // ahora sí con GL activo
                chunks.put(chunk.getKey(), chunk);
            }
            chunksToAdd.clear();
        }
    }

    public void setChunkLoader(ChunkLoaderThread loader) {
        this.chunkLoader = loader;
    }

    public void enqueueChunkToAdd(Chunk c) {
        synchronized (chunksToAdd) {
            chunksToAdd.add(c);
        }
    }

    public void enqueueChunkToMesh(Chunk c) {
        chunksToMesh.add(c);
    }

    public void enqueueChunkToIntegrate(Chunk c) {
        chunksToIntegrate.add(c);
    }

    /**
     * Renderiza todos los chunks cargados
     */
    public void render() {
        // 1) Calcula proyección y vista (o mantenlas en campos si no cambian cada frame)
        Matrix4f projection = camera.getProjectionMatrix(70, 1280f / 720f, 0.01f, 100f);
        Matrix4f view = camera.getViewMatrix();

        // 2) Bindea TU shader antes de setear uniforms
        shader.bind();
        // Ahora sí, OpenGL sabe que “viewPos” y “lightPos” van a este shader
        shader.setUniform3f("viewPos", camera.getEyePosition());
        shader.setUniform3f("lightDir", new Vector3f(-0.5f, -1.0f, -0.5f).normalize());
        shader.setUniformMat4("view", view);
        shader.setUniformMat4("projection", projection);
        // (También podrías setear aquí las matrices view/projection si no lo haces dentro de Chunk.render)

        // 3) Dibuja todos los chunks
        for (Chunk chunk : chunks.values()) {
            // Chunk.render seguirá bind() y unbind() internamente
            // pero como tú ya bindiaste el shader aquí, al menos los uniforms ya existen
            chunk.render(projection, view, shader, grass, dirt, stone);
        }

        // 4) Desbindea el shader cuando termines
        shader.unbind();
    }

    private String key(int x, int y, int z) {
        return x + "," + y + "," + z;
    }

    /**
     * Limpia todos los recursos de chunks
     */
    public void cleanup() {
        for (Chunk chunk : chunks.values()) {
            chunk.cleanup();
        }
        chunks.clear();
    }

    public void startThreads() {
        meshBuilder.start();
        saveThread.start();
    }

}
