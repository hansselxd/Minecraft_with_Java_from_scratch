package com.minecraftclone.core;

import java.util.ArrayList;
import java.util.List;

public class CubeGenerator {

    // Tamaño de cada celda de la textura (col: 3 columnas, row: 2 filas)
    private static final float UV_WIDTH = 1.0f / 3.0f;
    private static final float UV_HEIGHT = 1.0f / 2.0f;

    public static float[] createCube(int x, int y, int z, Block[][][] blocks) {
        List<Float> data = new ArrayList<>();

        for (Direction dir : Direction.values()) {
            int nx = x + dir.offsetX;
            int ny = y + dir.offsetY;
            int nz = z + dir.offsetZ;

            if (isAir(blocks, nx, ny, nz)) {
                // Elegimos coordenadas de textura según la cara
                int texCol = getTexCol(dir);
                int texRow = getTexRow(dir);
                boolean isShadow = isInShadow(nx, ny, nz, dir);
                float shade = isShadow ? 0.5f : 1.0f;
                addFace(data, x, y, z, dir, texCol, texRow, blocks, shade);
            }
        }

        float[] result = new float[data.size()];
        for (int i = 0; i < result.length; i++) {
            result[i] = data.get(i);
        }
        return result;
    }

    private static boolean isAir(Block[][][] blocks, int x, int y, int z) {
        if (x < 0 || x >= blocks.length || y < 0 || y >= blocks[0].length || z < 0 || z >= blocks[0][0].length) {
            return true; // Consideramos aire fuera de los límites
        }
        if (blocks[x][y][z].isSolid && blocks[x][y][z] != null) {
            return false;
        }
        return true;
    }

    public enum Direction {
        UP(0, 1, 0), DOWN(0, -1, 0),
        FRONT(0, 0, 1), BACK(0, 0, -1),
        LEFT(-1, 0, 0), RIGHT(1, 0, 0);

        public final int offsetX, offsetY, offsetZ;

        Direction(int x, int y, int z) {
            this.offsetX = x;
            this.offsetY = y;
            this.offsetZ = z;
        }
    }

    private static int getTexCol(Direction dir) {
        switch (dir) {
            case UP:
                return 0;
            case DOWN:
                return 2;
            case FRONT:
                return 1;
            case BACK:
                return 1;
            case LEFT:
                return 0;
            case RIGHT:
                return 2;
        }
        return 0;
    }

    private static int getTexRow(Direction dir) {
        switch (dir) {
            case UP:
                return 0;
            case DOWN:
                return 0;
            case FRONT:
                return 0;
            case BACK:
                return 1;
            case LEFT:
                return 1;
            case RIGHT:
                return 1;
        }
        return 0;
    }

    private static void addFace(List<Float> data, int x, int y, int z, Direction dir, int texCol, int texRow, Block[][][] blocks, Float lightLevel) {
        float[][] positions = CubeFace.getFaceVertices(dir);
        float[] normal = CubeFace.getNormal(dir);

        float u0 = texCol * UV_WIDTH;
        float v0 = texRow * UV_HEIGHT;
        float u1 = u0 + UV_WIDTH;
        float v1 = v0 + UV_HEIGHT;

        // UVs: se asignan en sentido horario desde esquina inferior izquierda
        float[][] uvs = new float[][]{
            {u0, v1},
            {u1, v1},
            {u1, v0},
            {u0, v0}
        };

        // calculo del ao
        float[] aoValues = new float[4];
        for (int i = 0; i < 4; i++) {
            // posLocal = posiciones del vértice en [0..1] relativo al cubo
            int localX = (int) positions[i][0];
            int localY = (int) positions[i][1];
            int localZ = (int) positions[i][2];

            aoValues[i] = computeAOForCorner(x, y, z, dir, localX, localY, localZ, blocks);
           }

        // Triángulo 1 (v0, v1, v2)
        addVertex(data, positions[0], uvs[0], normal, x, y, z, lightLevel, aoValues[0]);
        addVertex(data, positions[1], uvs[1], normal, x, y, z, lightLevel, aoValues[1]);
        addVertex(data, positions[2], uvs[2], normal, x, y, z, lightLevel, aoValues[2]);
        // Triángulo 2 (v2, v3, v0)
        addVertex(data, positions[2], uvs[2], normal, x, y, z, lightLevel, aoValues[2]);
        addVertex(data, positions[3], uvs[3], normal, x, y, z, lightLevel, aoValues[3]);
        addVertex(data, positions[0], uvs[0], normal, x, y, z, lightLevel, aoValues[0]);
    }

    private static float computeAOForCorner(
            int x, int y, int z,
            Direction dir,
            int localX, int localY, int localZ,
            Block[][][] blocks) {

        boolean side1 = false, side2 = false, corner = false;
        int bx, by, bz;

        switch (dir) {
            // ------- CARA SUPERIOR -------
            case UP:
                // Nivel base para la cara UP es y+1, pero vecinos para AO miramos a y:
                int worldX_up = x + localX;
                int worldY_up = y+1;       // ¡Ojo! usamos y, no y+1
                int worldZ_up = z + localZ;

                // side1: vecino en X positivo o negativo (misma Y)
                bx = worldX_up + ((localX == 0) ? -1 : +1);
                by = worldY_up;
                bz = worldZ_up;
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    side1 = true;
                }

                // side2: vecino en Z positivo o negativo (misma Y)
                bx = worldX_up;
                by = worldY_up;
                bz = worldZ_up + ((localZ == 0) ? -1 : +1);
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    side2 = true;
                }

                // corner: el vecino en la esquina diagonal (misma Y)
                bx = worldX_up + ((localX == 0) ? -1 : +1);
                by = worldY_up;
                bz = worldZ_up + ((localZ == 0) ? -1 : +1);
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    corner = true;
                }
                break;

            // ------- CARA INFERIOR -------
            case DOWN:
                // Para DOWN la cara está en y-1, pero vecinos siguen en y
                int worldX_down = x + localX;
                int worldY_down = y-1;  // OJO: nivel “y” (cara inferior apunta hacia abajo, pero AO se mira en y)
                int worldZ_down = z + localZ;

                // side1 en X
                bx = worldX_down + ((localX == 0) ? -1 : +1);
                by = worldY_down;
                bz = worldZ_down;
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    side1 = true;
                }
                // side2 en Z
                bx = worldX_down;
                by = worldY_down;
                bz = worldZ_down + ((localZ == 0) ? -1 : +1);
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    side2 = true;
                }
                // corner en diagonal (misma Y)
                bx = worldX_down + ((localX == 0) ? -1 : +1);
                by = worldY_down;
                bz = worldZ_down + ((localZ == 0) ? -1 : +1);
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    corner = true;
                }
                break;

            // ------- CARA FRONTAL -------
            case FRONT:
                // Cara FRONT en z+1, pero vecinos para AO en z:
                int worldX_front = x + localX;
                int worldY_front = y + localY; // en FRONTAL hay variación en Y
                int worldZ_front = z+1;

                // side1: x ±1, misma Z
                bx = worldX_front + ((localX == 0) ? -1 : +1);
                by = worldY_front;
                bz = worldZ_front;
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    side1 = true;
                }
                // side2: y ±1, misma Z
                bx = worldX_front;
                by = worldY_front + ((localY == 0) ? -1 : +1);
                bz = worldZ_front;
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    side2 = true;
                }
                // corner: diagonal en X e Y, misma Z
                bx = worldX_front + ((localX == 0) ? -1 : +1);
                by = worldY_front + ((localY == 0) ? -1 : +1);
                bz = worldZ_front;
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    corner = true;
                }
                break;

            // ------- CARA TRASERA -------
            case BACK:
                // Cara BACK en z-1, pero vecinos en z:
                int worldX_back = x + localX;
                int worldY_back = y + localY;
                int worldZ_back = z-1;

                // side1: x ±1, misma Z
                bx = worldX_back + ((localX == 0) ? -1 : +1);
                by = worldY_back;
                bz = worldZ_back;
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    side1 = true;
                }
                // side2: y ±1, misma Z
                bx = worldX_back;
                by = worldY_back + ((localY == 0) ? -1 : +1);
                bz = worldZ_back;
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    side2 = true;
                }
                // corner: diagonal en X e Y, misma Z
                bx = worldX_back + ((localX == 0) ? -1 : +1);
                by = worldY_back + ((localY == 0) ? -1 : +1);
                bz = worldZ_back;
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    corner = true;
                }
                break;

            // ------- CARA IZQUIERDA -------
            case LEFT:
                // Cara LEFT en x-1, vecinos en x:
                int worldX_left = x-1;
                int worldY_left = y + localY;
                int worldZ_left = z + localZ;

                // side1: z ±1, mismo X
                bx = worldX_left;
                by = worldY_left;
                bz = worldZ_left + ((localZ == 0) ? -1 : +1);
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    side1 = true;
                }
                // side2: y ±1, mismo X
                bx = worldX_left;
                by = worldY_left + ((localY == 0) ? -1 : +1);
                bz = worldZ_left;
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    side2 = true;
                }
                // corner: diagonal en Y y Z, mismo X
                bx = worldX_left;
                by = worldY_left + ((localY == 0) ? -1 : +1);
                bz = worldZ_left + ((localZ == 0) ? -1 : +1);
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    corner = true;
                }
                break;

            // ------- CARA DERECHA -------
            case RIGHT:
                // Cara RIGHT en x+1, vecinos en x:
                int worldX_right = x+1;
                int worldY_right = y + localY;
                int worldZ_right = z + localZ;

                // side1: z ±1, mismo X
                bx = worldX_right;
                by = worldY_right;
                bz = worldZ_right + ((localZ == 0) ? -1 : +1);
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    side1 = true;
                }
                // side2: y ±1, mismo X
                bx = worldX_right;
                by = worldY_right + ((localY == 0) ? -1 : +1);
                bz = worldZ_right;
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    side2 = true;
                }
                // corner: diagonal en Y y Z, mismo X
                bx = worldX_right;
                by = worldY_right + ((localY == 0) ? -1 : +1);
                bz = worldZ_right + ((localZ == 0) ? -1 : +1);
                if (inBounds(bx, by, bz, blocks) && blocks[bx][by][bz].isSolid()) {
                    corner = true;
                }
                break;
        }

        // Ahora calculamos el valor final de AO, entre 0.0 (muy oscuro) y 1.0 (sin oclusión).
        float ao;
        if (side1 && side2) {
            // Si ambos lados laterales están ocupados → esquina completamente cerrada
            ao = 0.0f;
        } else {
            // La fórmula es aproximada: 
            // → cada “lado ocupado” reduce 0.5
            // → la esquina diagonal reduce 0.2
            float occ = 0.0f;
            if (side1) {
                occ += 0.5f;
            }
            if (side2) {
                occ += 0.5f;
            }
            if (corner) {
                occ += 0.2f;
            }
            ao = 1.0f - occ;
            // Clamp a [0,1]
            if (ao < 0f) {
                ao = 0f;
            }
            if (ao > 1f) {
                ao = 1f;
            }
        }

        return ao;
    }

    /**
     * inBounds: verifica que (bx,by,bz) esté dentro de los límites del chunk
     * (blocks.length = SIZEx, blocks[0].length = SIZEy, blocks[0][0].length =
     * SIZEz).
     */
    private static boolean inBounds(int bx, int by, int bz, Block[][][] blocks) {
        return bx >= 0 && bx < blocks.length
                && by >= 0 && by < blocks[0].length
                && bz >= 0 && bz < blocks[0][0].length;
    }

    /**
     * Recorrer a partir de (x,y,z) en dirección 'dir', tantas celdas como sea
     * necesario hasta encontrar un bloque sólido. Si encuentra un bloque sólido
     * antes de quedarse sin mundo, devuelve true (hay sombra). En caso
     * contrario, devuelve false (no hay nada que proyecte sombra).
     */
    private static boolean isInShadow(int x, int y, int z, Direction dir) {
        // Partimos desde el primer vecino inmediato
        int cx = x + dir.offsetX;
        int cy = y + dir.offsetY;
        int cz = z + dir.offsetZ;

        // Mientras queden coordenadas “válidas” (getBlockIfLoader != null),
        // avanzamos en la misma dirección.
        while (true) {
            Block b = WorldManager.instance.getBlockIfLoader(cx, cy, cz);
            if (b == null) {
                // Nos salimos de los chunks cargados → asumimos que no hay sombra
                return false;
            }
            if (b != Block.AIR && b.isSolid()) {
                // Encontramos un bloque sólido → proyecta sombra
                return true;
            }
            // Si es aire, seguimos un paso más
            cx += dir.offsetX;
            cy += dir.offsetY;
            cz += dir.offsetZ;
        }
    }

    public static float[] createFace(float x, float y, float z, Direction dir, boolean inShadow) {
        // Vertices (posX, posY, posZ, u, v, normX, normY, normZ)
        switch (dir) {
            case FRONT:
                return new float[]{
                    x, y, z + 1, 0, 0, 0, 0, 1,
                    x + 1, y, z + 1, 1, 0, 0, 0, 1,
                    x + 1, y + 1, z + 1, 1, 1, 0, 0, 1,
                    x + 1, y + 1, z + 1, 1, 1, 0, 0, 1,
                    x, y + 1, z + 1, 0, 1, 0, 0, 1,
                    x, y, z + 1, 0, 0, 0, 0, 1
                };

            case BACK:
                return new float[]{
                    x + 1, y, z, 0, 0, 0, 0, -1,
                    x, y, z, 1, 0, 0, 0, -1,
                    x, y + 1, z, 1, 1, 0, 0, -1,
                    x, y + 1, z, 1, 1, 0, 0, -1,
                    x + 1, y + 1, z, 0, 1, 0, 0, -1,
                    x + 1, y, z, 0, 0, 0, 0, -1
                };

            case LEFT:
                return new float[]{
                    x, y, z, 0, 0, -1, 0, 0,
                    x, y, z + 1, 1, 0, -1, 0, 0,
                    x, y + 1, z + 1, 1, 1, -1, 0, 0,
                    x, y + 1, z + 1, 1, 1, -1, 0, 0,
                    x, y + 1, z, 0, 1, -1, 0, 0,
                    x, y, z, 0, 0, -1, 0, 0
                };

            case RIGHT:
                return new float[]{
                    x + 1, y, z + 1, 0, 0, 1, 0, 0,
                    x + 1, y, z, 1, 0, 1, 0, 0,
                    x + 1, y + 1, z, 1, 1, 1, 0, 0,
                    x + 1, y + 1, z, 1, 1, 1, 0, 0,
                    x + 1, y + 1, z + 1, 0, 1, 1, 0, 0,
                    x + 1, y, z + 1, 0, 0, 1, 0, 0
                };

            case UP:
                return new float[]{
                    x, y + 1, z + 1, 0, 0, 0, 1, 0,
                    x + 1, y + 1, z + 1, 1, 0, 0, 1, 0,
                    x + 1, y + 1, z, 1, 1, 0, 1, 0,
                    x + 1, y + 1, z, 1, 1, 0, 1, 0,
                    x, y + 1, z, 0, 1, 0, 1, 0,
                    x, y + 1, z + 1, 0, 0, 0, 1, 0
                };

            case DOWN:
                return new float[]{
                    x, y, z, 0, 0, 0, -1, 0,
                    x + 1, y, z, 1, 0, 0, -1, 0,
                    x + 1, y, z + 1, 1, 1, 0, -1, 0,
                    x + 1, y, z + 1, 1, 1, 0, -1, 0,
                    x, y, z + 1, 0, 1, 0, -1, 0,
                    x, y, z, 0, 0, 0, -1, 0
                };
        }

        return new float[0]; // Fallback
    }

    private static void addVertex(List<Float> data, float[] pos, float[] uv, float[] normal, int x, int y, int z, Float shade, float ao) {
        data.add(pos[0] + x);
        data.add(pos[1] + y);
        data.add(pos[2] + z);

        data.add(normal[0]);
        data.add(normal[1]);
        data.add(normal[2]);

        data.add(uv[0]);
        data.add(uv[1]);

        data.add(shade);

        data.add(ao);

    }
}
